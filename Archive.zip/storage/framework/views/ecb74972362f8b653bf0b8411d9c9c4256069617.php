<div class="row">
    <nav class="col-md-2 d-none d-md-block bg-light sidebar">
        <div class="sidebar-sticky">
            <?php echo $__env->make('partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </nav>

    <main role="main" class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4">

        <?php if(Session::has('success')): ?>
            <div class="alert alert-success" role="alert">
                <span data-feather="check-circle"></span>
                <?php echo e(Session::get('success')); ?>

            </div>
        <?php endif; ?>

        <?php if(Session::has('error')): ?>
            <div class="alert alert-danger" role="alert">
                <span data-feather="x-circle"></span>
                <?php echo e(Session::get('error')); ?>

            </div>
        <?php endif; ?>

        <?php echo $__env->yieldContent('main'); ?>
    </main>
</div>