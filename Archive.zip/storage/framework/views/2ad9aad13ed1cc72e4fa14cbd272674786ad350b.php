<ul class="nav flex-column">
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('categories.index')); ?>">
            <span data-feather="briefcase"></span>
            Categories
        </a>
    </li>
</ul>