<?php $__env->startSection('main'); ?>

    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3">
        <h1 class="h2">Categories</h1>
        <div class="btn-toolbar mb-2 mb-md-0">
            <div class="btn-group mr-2">
                <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-primary"><span data-feather="plus"></span> Create</a>
            </div>
        </div>
    </div>

    <div class="table-responsive">
        <table class="table table-bordered table-vcenter table-hover table-striped">
            <thead>
            <tr>
                <th>ID</th>
                <th>Category name</th>
                <th>Description</th>
                <th>Image</th>
                <th>Icon</th>
                <th class="text-center">Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($cat->id); ?></td>
                    <td><?php echo e($cat->name); ?></td>
                    <td><?php echo e($cat->description); ?></td>
                    <td><img   width="30px" src="./images/<?php echo e($cat->image); ?>" ></td>
                    <td><img   width="30px" src="./images/<?php echo e($cat->category_map_marker); ?>" ></td>
                    <td class="text-center">
                        <div class="btn-group btn-group-sm">
                            <a href="<?php echo e(route('categories.edit', $cat->id)); ?>" class="btn btn-warning"><span data-feather="edit-2"></span></a>
                            <!-- <a data-method="DELETE" data-confirm="Are you sure?" href="<?php echo e(route('categories.destroy', $cat->id)); ?>" class="btn btn-danger"><span data-feather="x"></span></a> -->
                            <?php echo Form::open(['method' => 'DELETE', 'route' => ['categories.destroy', $cat->id],'onsubmit' => 'return confirm("Are you sure?")', 'id'=>$cat->id]); ?>

                            <a href="#" onclick="$(this).closest('form').submit();">Delete</a>
                            <?php echo Form::close(); ?>

                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>