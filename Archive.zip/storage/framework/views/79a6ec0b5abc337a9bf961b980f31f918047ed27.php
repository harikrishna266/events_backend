<div class="mb-3">
    <?php echo Form::label('name','Category Name', ['class' => 'control-label']); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control' . ($errors->has('name') ? ' is-invalid' : '') ]); ?>

    <?php echo $errors->first('name', '<span class="invalid-feedback">:message</span>'); ?>

</div>

<div class="mb-3">
    <?php echo Form::label('description','description', ['class' => 'control-label']); ?>

    <?php echo Form::text('description', null, ['class' => 'form-control' . ($errors->has('description') ? ' is-invalid' : '') ]); ?>

    <?php echo $errors->first('street', '<span class="invalid-feedback">:message</span>'); ?>

</div>

<div class="mb-3">
    <?php echo Form::label('image','image', ['class' => 'control-label']); ?>

    <?php echo Form::file('image', null, ['class' => 'form-control' . ($errors->has('image') ? ' is-invalid' : '') ]); ?>

    <?php echo $errors->first('image', '<span class="invalid-feedback">:message</span>'); ?>

</div>

<div class="mb-3">
    <?php echo Form::label('map_icon','map_icon', ['class' => 'control-label']); ?>

    <?php echo Form::file('category_map_marker', null, ['class' => 'form-control' . ($errors->has('category_map_marker') ? ' is-invalid' : '') ]); ?>

    <?php echo $errors->first('category_map_marker', '<span class="invalid-feedback">:message</span>'); ?>

</div>
