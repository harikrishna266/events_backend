<?php $__env->startSection('main'); ?>

    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3">
        <h1 class="h2">Create Event</h1>
        <div class="btn-toolbar mb-2 mb-md-0">
            <div class="btn-group mr-2">
                <a href="<?php echo e(route('events.index')); ?>" class="btn btn-outline-secondary">
                    <span data-feather="arrow-left"></span> Back to events
                </a>
            </div>
        </div>
    </div>

    <div class="row">

        <div class="col-md-6">
            <?php echo Form::open(['route' => 'events.store' ,'enctype' => 'multipart/form-data']); ?>


            <?php echo $__env->make('events.partials.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <button class="btn btn-primary btn-lg" type="submit">
                <span data-feather="plus"></span> Create Events
            </button>

            <?php echo Form::close(); ?>

        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>